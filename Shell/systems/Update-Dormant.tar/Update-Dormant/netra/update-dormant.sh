#!/bin/bash

/root/update.var.sh
/root/update.root.sh
