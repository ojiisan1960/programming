#!/bin/bash

/root/update.data.sh
/root/update.root.sh
