#!/usr/bin/perl -w
# hello1.pl

@message = ("\n", " ", "World", "Hello,");
print $message[3], $message[1], $message[2], $message[0];
