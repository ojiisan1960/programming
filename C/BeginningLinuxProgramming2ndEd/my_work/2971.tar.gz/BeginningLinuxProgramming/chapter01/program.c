#include "lib.h"

int main()
{
    bill("Hello World");
    exit(0);
}
