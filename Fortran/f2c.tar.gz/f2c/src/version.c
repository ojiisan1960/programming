char F2C_version[] = "19991025";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 19991025\n";
